from sqlalchemy import Table, Column, Integer, String, MetaData

meta = MetaData()

files = Table(
    "files",
    meta,
    Column("id", Integer, primary_key=True),
    Column("file_name", String(255), nullable=False),
    Column("file_format", String(10), nullable=False)
)

