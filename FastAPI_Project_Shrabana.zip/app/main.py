from fastapi import FastAPI, UploadFile, File, HTTPException, Body
from sqlalchemy import insert, select
from fastapi.responses import JSONResponse
from app.database import SessionLocal
from app.models import files
from app.minio_client import minio_client, MINIO_BUCKET
from fastapi_cache import FastAPICache
from fastapi_cache.backends.inmemory import InMemoryBackend
import pandas as pd
import uuid
import os
from datetime import datetime

#  Initialize FastAPI app
app = FastAPI(title="FastAPI File Management with PostgreSQL, MinIO, and Caching")

#  Local folder for temporary storage before MinIO upload/download
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


#  Home endpoint
@app.get("/")
def home():
    return {"message": "FastAPI app is running successfully with MinIO integration!"}


#  POST Method — Upload multiple files and save to MinIO
@app.post("/upload/")
async def upload_files(files_list: list[UploadFile] = File(...)):
    db = SessionLocal()
    uploaded_files = []

    for file in files_list:
        file_ext = file.filename.split(".")[-1].lower()
        if file_ext not in ["csv", "xlsx"]:
            raise HTTPException(status_code=400, detail=f"{file.filename} is not a CSV/XLSX file")

        # Save temporarily before uploading to MinIO
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())

        #  Upload to MinIO
        minio_client.fput_object(MINIO_BUCKET, file.filename, file_path)

        # Remove local temporary file
        os.remove(file_path)

        #  Insert metadata into PostgreSQL
        query = insert(files).values(file_name=file.filename, file_format=file_ext)
        db.execute(query)
        uploaded_files.append(file.filename)

    db.commit()
    db.close()

    return {"message": "Files uploaded successfully to MinIO", "uploaded_files": uploaded_files}


#  GET Method — View all stored files
@app.get("/files/")
def get_all_files():
    db = SessionLocal()
    query = select(files)
    result = db.execute(query).fetchall()
    db.close()

    file_list = [{"id": row.id, "file_name": row.file_name, "file_format": row.file_format} for row in result]
    return JSONResponse(content={"files": file_list})


#  GET Method — Merge two files temporarily (from MinIO)
@app.get("/merge/")
async def merge_two_files(file_id_1: int, file_id_2: int):
    db = SessionLocal()
    query = select(files).where(files.c.id.in_([file_id_1, file_id_2]))
    result = db.execute(query).fetchall()
    db.close()

    if len(result) != 2:
        raise HTTPException(status_code=404, detail="One or both file IDs not found")

    df_list = []

    #  Download both files from MinIO temporarily
    for row in result:
        file_path = os.path.join(UPLOAD_DIR, row.file_name)
        minio_client.fget_object(MINIO_BUCKET, row.file_name, file_path)
        df_list.append(pd.read_csv(file_path))
        os.remove(file_path)  # cleanup after reading

    df1, df2 = df_list

    #  Ensure common column exists
    if "customer_id" not in df1.columns or "customer_id" not in df2.columns:
        raise HTTPException(status_code=400, detail="Both files must have 'customer_id' column")

    #  Merge files
    merged_df = pd.merge(df1, df2, on="customer_id", how="inner")

    #  Initialize cache backend (if not already)
    backend = FastAPICache.get_backend()
    if backend is None:
        FastAPICache.init(InMemoryBackend(), prefix="fastapi-cache")
        backend = FastAPICache.get_backend()

    #  Cache merged data temporarily (10 min)
    cache_key = str(uuid.uuid4())
    await backend.set(cache_key, merged_df.to_json(), expire=600)

    #  Return preview and cache key
    preview = merged_df.head(5).to_dict(orient="records")
    return {"cache_key": cache_key, "preview": preview}


#  POST Method — Save merged dataset permanently to MinIO
@app.post("/save-merged/")
async def save_merged_dataset(data: dict = Body(...)):
    cache_key = data.get("cache_key")
    backend = FastAPICache.get_backend()
    cached_data = await backend.get(cache_key)

    if not cached_data:
        raise HTTPException(status_code=404, detail="Merged dataset not found or expired")

    #  Decode cached JSON
    if isinstance(cached_data, bytes):
        cached_data = cached_data.decode("utf-8")

    merged_df = pd.read_json(cached_data)

    #  Create merged file name
    new_filename = f"merged_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    save_path = os.path.join(UPLOAD_DIR, new_filename)

    #  Save locally, then upload to MinIO
    merged_df.to_csv(save_path, index=False)
    minio_client.fput_object(MINIO_BUCKET, new_filename, save_path)
    os.remove(save_path)

    #  Insert metadata into PostgreSQL
    db = SessionLocal()
    query = insert(files).values(file_name=new_filename, file_format="csv")
    db.execute(query)
    db.commit()
    db.close()

    #  Clear cache safely
    try:
        await backend.delete(cache_key)
    except Exception:
        pass

    return {"message": "Merged dataset saved successfully to MinIO!", "file_name": new_filename}


#  Initialize cache on startup
@app.on_event("startup")
async def startup_event():
    FastAPICache.init(InMemoryBackend(), prefix="fastapi-cache")

