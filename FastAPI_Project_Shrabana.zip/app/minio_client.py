from minio import Minio
from dotenv import load_dotenv
import os

# ✅ Load .env from current app directory
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

# ✅ Read environment variables
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY")
MINIO_BUCKET = os.getenv("MINIO_BUCKET")
MINIO_USE_SSL = os.getenv("MINIO_USE_SSL", "False").lower() == "true"

# ✅ Print to confirm values are loaded (optional for debugging)
print("✅ MinIO Configuration Loaded:")
print("Endpoint:", MINIO_ENDPOINT)
print("Bucket:", MINIO_BUCKET)

# ✅ Create MinIO client
minio_client = Minio(
    MINIO_ENDPOINT,
    access_key=MINIO_ACCESS_KEY,
    secret_key=MINIO_SECRET_KEY,
    secure=MINIO_USE_SSL
)

# ✅ Ensure the bucket exists
found = minio_client.bucket_exists(MINIO_BUCKET)
if not found:
    minio_client.make_bucket(MINIO_BUCKET)
    print(f"✅ Created bucket: {MINIO_BUCKET}")
else:
    print(f"✅ Bucket already exists: {MINIO_BUCKET}")


